var valorEmDolarTexto = prompt("Qual o valor em dolar você quer converter?")

var valorEmDolarNumero = parseInt(valorEmDolarTexto)

var valorEmReal = valorEmDolarNumero * 5.50

alert(valorEmReal)